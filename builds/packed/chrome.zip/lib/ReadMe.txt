String_random:
  https://github.com/cho45/String_random.js/blob/master/lib/String_random.js
