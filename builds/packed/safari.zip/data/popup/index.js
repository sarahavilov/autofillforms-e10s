/* globals background, Fuse */
'use strict';

var select = document.querySelector('select');
var profile = document.getElementById('profile');
var search = document.getElementById('search');

var fuse = {
  search: function search() {
    return [0];
  }
};

document.addEventListener('click', function (e) {
  var cmd = e.target.dataset.cmd;
  if (cmd) {
    background.send(cmd);
    window.close();
  }
});
// select
(function (callback) {
  var old = select.value;
  function check() {
    var value = select.value;
    if (value !== old) {
      old = value;
      callback(value);
    }
  }
  select.addEventListener('change', check);
  select.addEventListener('click', check);
})(function (value) {
  background.send('profile', value);
  profile.textContent = value;
});

background.receive('show', function (obj) {
  console.error(obj);
  select.textContent = '';
  var list = ['default'].concat(obj.list);
  fuse = new Fuse(list);
  list.forEach(function (name, index) {
    var option = document.createElement('option');
    option.textContent = option.value = name;
    select.appendChild(option);
    if (name === obj.current) {
      select.selectedIndex = index;
      profile.textContent = name;
    }
  });
});

search.addEventListener('keypress', function () {
  var index = fuse.search(search.value)[0] || 0;
  var value = fuse.list[index];
  background.send('profile', value);
  profile.textContent = value;
});