/* globals safari */
'use strict';

var background = function () {
  // jshint ignore:line
  var callbacks = {};
  return {
    send: function send(id, data) {
      return safari.extension.globalPage.contentWindow.app.popup.dispatchMessage(id, data);
    },
    receive: function receive(id, callback) {
      callbacks[id] = callbacks[id] || [];
      callbacks[id].push(callback);
    },
    dispatchMessage: function dispatchMessage(id, data) {
      return (callbacks[id] || []).forEach(function (c) {
        return c(data);
      });
    }
  };
}();