/* globals safari */
'use strict';

var background = { // jshint ignore:line
  send: function send(id, data) {
    return safari.self.tab.dispatchMessage('message', {
      id: id,
      data: data
    });
  },
  receive: function () {
    var callbacks = {};
    safari.self.addEventListener('message', function (e) {
      (callbacks[e.name] || []).forEach(function (c) {
        return c(e.message);
      });
    }, false);

    return function (id, callback) {
      callbacks[id] = callbacks[id] || [];
      callbacks[id].push(callback);
    };
  }()
};

document.addEventListener('contextmenu', function (e) {
  safari.self.tab.setContextMenuEventUserInfo(e, e.target.nodeName);
}, false);